
package object.MCI3.Outgoing;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "username",
    "password",
    "binary",
    "delete",
    "disconnect",
    "passiveMode",
    "maximumReconnectAttempts",
    "reconnectDelay",
    "connectTimeout",
    "soTimeout",
    "maxMessagesPerPoll",
    "ftpClient.proxyUrl",
    "replyTo",
    "preserveMessageQos",
    "exchangePattern"
})
public class Params_ {

    @JsonProperty("username")
    private String username;
    @JsonProperty("password")
    private String password;
    @JsonProperty("binary")
    private String binary;
    @JsonProperty("delay")
    private String delay;
    @JsonProperty("delete")
    private String delete;
    @JsonProperty("disconnect")
    private String disconnect;
    @JsonProperty("passiveMode")
    private String passiveMode;
    @JsonProperty("maximumReconnectAttempts")
    private String maximumReconnectAttempts;
    @JsonProperty("reconnectDelay")
    private String reconnectDelay;
    @JsonProperty("connectTimeout")
    private String connectTimeout;
    @JsonProperty("soTimeout")
    private String soTimeout;
    @JsonProperty("maxMessagesPerPoll")
    private String maxMessagesPerPoll;
    @JsonProperty("ftpClient.proxyUrl")
    private String ftpClientProxyUrl;

    @JsonProperty("replyTo")
    private String replyTo;
    @JsonProperty("preserveMessageQos")
    private String preserveMessageQos;
    @JsonProperty("exchangePattern")
    private String exchangePattern;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * 
     * @return
     *     The username
     */
    @JsonProperty("username")
    public String getUsername() {
        return username;
    }

    /**
     * 
     * @param username
     *     The username
     */
    @JsonProperty("username")
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * 
     * @return
     *     The password
     */
    @JsonProperty("password")
    public String getPassword() {
        return password;
    }

    /**
     * 
     * @param password
     *     The password
     */
    @JsonProperty("password")
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * 
     * @return
     *     The binary
     */
    @JsonProperty("binary")
    public String getBinary() {
        return binary;
    }

    /**
     * 
     * @param binary
     *     The binary
     */
    @JsonProperty("binary")
    public void setBinary(String binary) {
        this.binary = binary;
    }

    /**
     *
     * @return
     *     The delay
     */
    @JsonProperty("delay")
    public String getDelay() {
        return delay;
    }

    /**
     *
     * @param delay
     *     The delay
     */
    @JsonProperty("delay")
    public void setDelay(String delay) {
        this.delay = delay;
    }

    /**
     * 
     * @return
     *     The delete
     */
    @JsonProperty("delete")
    public String getDelete() {
        return delete;
    }

    /**
     * 
     * @param delete
     *     The delete
     */
    @JsonProperty("delete")
    public void setDelete(String delete) {
        this.delete = delete;
    }

    /**
     * 
     * @return
     *     The disconnect
     */
    @JsonProperty("disconnect")
    public String getDisconnect() {
        return disconnect;
    }

    /**
     * 
     * @param disconnect
     *     The disconnect
     */
    @JsonProperty("disconnect")
    public void setDisconnect(String disconnect) {
        this.disconnect = disconnect;
    }

    /**
     * 
     * @return
     *     The passiveMode
     */
    @JsonProperty("passiveMode")
    public String getPassiveMode() {
        return passiveMode;
    }

    /**
     * 
     * @param passiveMode
     *     The passiveMode
     */
    @JsonProperty("passiveMode")
    public void setPassiveMode(String passiveMode) {
        this.passiveMode = passiveMode;
    }

    /**
     * 
     * @return
     *     The maximumReconnectAttempts
     */
    @JsonProperty("maximumReconnectAttempts")
    public String getMaximumReconnectAttempts() {
        return maximumReconnectAttempts;
    }

    /**
     * 
     * @param maximumReconnectAttempts
     *     The maximumReconnectAttempts
     */
    @JsonProperty("maximumReconnectAttempts")
    public void setMaximumReconnectAttempts(String maximumReconnectAttempts) {
        this.maximumReconnectAttempts = maximumReconnectAttempts;
    }

    /**
     * 
     * @return
     *     The reconnectDelay
     */
    @JsonProperty("reconnectDelay")
    public String getReconnectDelay() {
        return reconnectDelay;
    }

    /**
     * 
     * @param reconnectDelay
     *     The reconnectDelay
     */
    @JsonProperty("reconnectDelay")
    public void setReconnectDelay(String reconnectDelay) {
        this.reconnectDelay = reconnectDelay;
    }

    /**
     * 
     * @return
     *     The connectTimeout
     */
    @JsonProperty("connectTimeout")
    public String getConnectTimeout() {
        return connectTimeout;
    }

    /**
     * 
     * @param connectTimeout
     *     The connectTimeout
     */
    @JsonProperty("connectTimeout")
    public void setConnectTimeout(String connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    /**
     * 
     * @return
     *     The soTimeout
     */
    @JsonProperty("soTimeout")
    public String getSoTimeout() {
        return soTimeout;
    }

    /**
     * 
     * @param soTimeout
     *     The soTimeout
     */
    @JsonProperty("soTimeout")
    public void setSoTimeout(String soTimeout) {
        this.soTimeout = soTimeout;
    }
/**
     *
     * @return
     *     The maxMessagesPerPoll
     */
    @JsonProperty("maxMessagesPerPoll")
    public String getMaxMessagesPerPoll() {
        return maxMessagesPerPoll;
    }

    /**
     *
     * @param maxMessagesPerPoll
     *     The maxMessagesPerPoll
     */
    @JsonProperty("maxMessagesPerPoll")
    public void setMaxMessagesPerPoll(String maxMessagesPerPoll) {
        this.maxMessagesPerPoll = maxMessagesPerPoll;
    }

    /**
     * 
     * @return
     *     The ftpClientProxyUrl
     */
    @JsonProperty("ftpClient.proxyUrl")
    public String getFtpClientProxyUrl() {
        return ftpClientProxyUrl;
    }

    /**
     * 
     * @param ftpClientProxyUrl
     *     The ftpClient.proxyUrl
     */
    @JsonProperty("ftpClient.proxyUrl")
    public void setFtpClientProxyUrl(String ftpClientProxyUrl) {
        this.ftpClientProxyUrl = ftpClientProxyUrl;
    }

    /**
     *
     * @return
     *     The replyTo
     */
    @JsonProperty("replyTo")
    public String getReplyTo() {
        return replyTo;
    }

    /**
     *
     * @param replyTo
     *     The replyTo
     */
    @JsonProperty("replyTo")
    public void setReplyTo(String replyTo) {
        this.replyTo = replyTo;
    }


    /**
     *
     * @return
     *     The preserveMessageQos
     */
    @JsonProperty("preserveMessageQos")
    public String getPreserveMessageQos() {
        return preserveMessageQos;
    }

    /**
     *
     * @param preserveMessageQos
     *     The preserveMessageQos
     */
    @JsonProperty("preserveMessageQos")
    public void setPreserveMessageQos(String preserveMessageQos) {
        this.preserveMessageQos = preserveMessageQos;
    }

    /**
     *
     * @return
     *     The exchangePattern
     */
    @JsonProperty("exchangePattern")
    public String getExchangePattern() {
        return exchangePattern;
    }

    /**
     *
     * @param exchangePattern
     *     The exchangePattern
     */
    @JsonProperty("exchangePattern")
    public void setExchangePattern(String exchangePattern) {
        this.exchangePattern = exchangePattern;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
